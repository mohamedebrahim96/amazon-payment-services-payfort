# PayfortTest
this sample show how to integrate Payfort SDK to android App
